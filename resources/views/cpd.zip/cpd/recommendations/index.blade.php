@extends('layouts.app')

@section('page-title', 'CPD Recommendations - UTB HR Nexus')

@section('content')
<div class="content-card">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px;">
        <h2 style="color: #2c3e50; margin: 0;">CPD Recommendations</h2>
        <a href="{{ route('cpd.index') }}" style="background: #6c757d; color: white; padding: 10px 20px; text-decoration: none; border-radius: 6px; font-weight: 600;">
            Back to CPD Applications
        </a>
    </div>

    @if(session('success'))
        <div style="background: #d4edda; color: #155724; padding: 15px; border-radius: 8px; margin-bottom: 20px; border: 1px solid #c3e6cb;">
            {{ session('success') }}
        </div>
    @endif

    @if(session('warning'))
        <div style="background: #fff3cd; color: #856404; padding: 15px; border-radius: 8px; margin-bottom: 20px; border: 1px solid #ffeaa7;">
            {{ session('warning') }}
        </div>
    @endif

    @if($recommendations->count() > 0)
        <div style="background: white; border-radius: 12px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); overflow: hidden;">
            <table style="width: 100%; border-collapse: collapse;">
                <thead>
                    <tr style="background: #f8f9fa;">
                        @if(Auth::user()->role === 'Administrator')
                            <th style="padding: 15px; text-align: left; border-bottom: 2px solid #dee2e6; font-weight: 600; color: #495057;">Applicant</th>
                        @endif
                        <th style="padding: 15px; text-align: left; border-bottom: 2px solid #dee2e6; font-weight: 600; color: #495057;">Event</th>
                        <th style="padding: 15px; text-align: left; border-bottom: 2px solid #dee2e6; font-weight: 600; color: #495057;">Event Date</th>
                        <th style="padding: 15px; text-align: left; border-bottom: 2px solid #dee2e6; font-weight: 600; color: #495057;">Created</th>
                        <th style="padding: 15px; text-align: center; border-bottom: 2px solid #dee2e6; font-weight: 600; color: #495057;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($recommendations as $recommendation)
                        <tr style="border-bottom: 1px solid #dee2e6;">
                            @if(Auth::user()->role === 'Administrator')
                                <td style="padding: 15px;">
                                    <div style="font-weight: 600; color: #2c3e50;">{{ $recommendation->applicant_name }}</div>
                                    <div style="font-size: 12px; color: #6c757d;">{{ $recommendation->applicant_post }}</div>
                                </td>
                            @endif
                            <td style="padding: 15px;">
                                <div style="font-weight: 600; color: #2c3e50;">{{ $recommendation->event_title }}</div>
                                <div style="font-size: 12px; color: #6c757d;">{{ $recommendation->event_type }}</div>
                            </td>
                            <td style="padding: 15px; color: #495057;">
                                {{ $recommendation->event_date->format('M d, Y') }}
                            </td>
                            <td style="padding: 15px; color: #6c757d; font-size: 14px;">
                                {{ $recommendation->created_at->format('M d, Y') }}
                            </td>
                            <td style="padding: 15px; text-align: center;">
                                <div style="display: flex; gap: 8px; justify-content: center;">
                                    <a href="{{ route('cpd.recommendations.show', $recommendation) }}" 
                                       style="background: #17a2b8; color: white; padding: 6px 12px; text-decoration: none; border-radius: 4px; font-size: 12px;">
                                        View
                                    </a>
                                        
                                    @if(Auth::user()->role === 'Administrator')
                                        <a href="{{ route('cpd.recommendations.edit', $recommendation) }}" 
                                           style="background: #ffc107; color: #212529; padding: 6px 12px; text-decoration: none; border-radius: 4px; font-size: 12px;">
                                            Edit
                                        </a>
                                            
                                        <form action="{{ route('cpd.recommendations.destroy', $recommendation) }}" method="POST" style="display: inline;">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" 
                                                    style="background: #dc3545; color: white; padding: 6px 12px; border: none; border-radius: 4px; font-size: 12px; cursor: pointer;"
                                                    onclick="return confirm('Are you sure you want to delete this recommendation?')">
                                                Delete
                                            </button>
                                        </form>
                                    @endif
                                </div>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    @else
        <div style="background: white; padding: 40px; border-radius: 12px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); text-align: center;">
            <div style="font-size: 48px; color: #dee2e6; margin-bottom: 20px;">📋</div>
            @if(Auth::user()->role === 'Administrator')
                <h3 style="color: #6c757d; margin-bottom: 10px;">No Recommendations Found</h3>
                <p style="color: #6c757d; margin-bottom: 20px;">You haven't created any CPD recommendations yet.</p>
            @else
                <h3 style="color: #6c757d; margin-bottom: 10px;">No Recommendations Found</h3>
                <p style="color: #6c757d; margin-bottom: 20px;">No recommendations have been created for your CPD applications yet.</p>
            @endif
            <a href="{{ route('cpd.index') }}" style="background: #3498db; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; font-weight: 600;">
                View CPD Applications
            </a>
        </div>
    @endif
</div>

<style>
.content-card {
    background: #f8f9fa;
    padding: 30px;
    border-radius: 12px;
    margin: 20px;
}

@media (max-width: 768px) {
    .content-card {
        margin: 10px;
        padding: 20px;
    }
    
    table {
        font-size: 14px;
    }
    
    th, td {
        padding: 10px 8px !important;
    }
}
</style>
@endsection 